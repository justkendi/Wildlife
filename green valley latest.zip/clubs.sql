CREATE TABLE `green_valley`.`clubs_register`
(`name` VARCHAR(100) NOT NULL ,
`email` VARCHAR(100) NOT NULL ,
`interests` VARCHAR(100) NOT NULL ,
`location` VARCHAR(100) NOT NULL ,
`gender` VARCHAR(100) NOT NULL )
ENGINE = InnoDB;